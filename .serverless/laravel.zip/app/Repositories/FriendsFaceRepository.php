<?php

namespace App\Repositories;

class FriendsFaceRepository extends AbstractRepository
{
//    public function ()
//    {
//
//    }
}
